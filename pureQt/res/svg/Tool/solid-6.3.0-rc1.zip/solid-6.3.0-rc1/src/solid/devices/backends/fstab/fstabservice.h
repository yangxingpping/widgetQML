/*
    SPDX-FileCopyrightText: 2010 Mario Bensi <mbensi@ipsquad.net>

    SPDX-License-Identifier: LGPL-2.1-only OR LGPL-3.0-only OR LicenseRef-KDE-Accepted-LGPL
*/

#ifndef SOLID_BACKENDS_FSTAB_SERVICE_H
#define SOLID_BACKENDS_FSTAB_SERVICE_H

/* FStab */
#define FSTAB_UDI_PREFIX "/org/kde/fstab"

#endif // SOLID_BACKENDS_FSTAB_H
