#ifndef UDEVQT_H
#define UDEVQT_H

#include "udevqtclient.h"
#include "udevqtdevice.h"

#endif
