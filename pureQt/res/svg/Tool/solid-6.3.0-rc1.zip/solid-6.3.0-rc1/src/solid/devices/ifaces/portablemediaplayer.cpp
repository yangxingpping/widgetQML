/*
    SPDX-FileCopyrightText: 2006 Davide Bettio <davide.bettio@kdemail.net>

    SPDX-License-Identifier: LGPL-2.1-only OR LGPL-3.0-only OR LicenseRef-KDE-Accepted-LGPL
*/

#include "portablemediaplayer.h"

Solid::Ifaces::PortableMediaPlayer::~PortableMediaPlayer()
{
}
