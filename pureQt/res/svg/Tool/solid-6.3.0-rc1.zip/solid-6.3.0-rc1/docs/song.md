A Solid Song   {#song}
=============


And for HAL's sake, each mistake, ah, you forgave<br>
And soon both of us learned to trust<br>
Not run away, it was no time to play;<br>
We built it up and built it up and committed it.

And now it's solid,<br>
%Solid as a rock;<br>
That's what this code is,<br>
That's what we've got, oh, mmm?

%Solid (Oh),<br>
%Solid as a rock;<br>
And nothing's changed it (Ooh),<br>
The code is still hot, hot, hot, hot, hot, hot, hot, hot
